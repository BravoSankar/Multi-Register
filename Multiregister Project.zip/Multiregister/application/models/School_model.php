<?php
defined('BASEPATH') or exit('No direct script access allowed');

class School_model extends CI_Model
{
    public function insert_teacher($teach){
        $this->db->insert('teacher',$teach);
    }
    public function insert_student($stud)
    {
        $this->db->insert('student',$stud);
    }
    public function login_student($enum,$pass)
    {
       $stud = $this->db->query("SELECT * FROM student WHERE `stupassword`='$pass'AND (`stuemail`='$enum'OR `stunumber` ='$enum')");
       return $stud->row();
    }
    public function login_teacher($enum,$pass)
    {
       $teach = $this->db->query("SELECT * FROM teacher WHERE `teapassword`='$pass'AND (`teaemail`='$enum'OR `teanumber` ='$enum')");
        return $teach->row();
    }
    public function update($data,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('teacher',$data);
    }
    public function stud_data()
    {
        $this->db->select('*');
        $data = $this->db->get('student');
        return $data->result_array();
    }
    public function ajax_insert($data){
       $query = $this->db->insert('ajax',$data);
       return $query;
    }
    public function get_userdata(){
        $query = $this->db->select('*')->get('ajax');
        $data = $query->result();
        if(isset($data)){
            return $data;
        } else{
            return false;
        }
    }
}
?>  