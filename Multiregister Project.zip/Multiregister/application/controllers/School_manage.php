<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class School_manage extends CI_Controller {

	public function index()
	{
		$this->load->view('home');
	}
	public function insert()
	{
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('pass','Password','required');
		if($this->form_validation->run()== false)
		{
			$this->load->view('home');

		}
		else{
         $name = $this->input->post('name');
		 $num = $this->input->post('num');
		 $email = $this->input->post('email');
		 $password = $this->input->post('pass');
		 $check = $this->input->post('find');
	   if($check == "one")
	   {
		   $teacher = array(
			'teaname' => $name,
			'teanumber' => $num,
			'teaemail' => $email,
			'teapassword' => $password,
			'role' => $check
		   );
           $this->School_model->insert_teacher($teacher);
		   redirect('school_manage/index');
	   }
	   else{
		$student = array(
			'stuname' => $name,
			'stunumber' => $num,
			'stuemail' => $email,
			'stupassword' => $password,
			'role' => $check
		);
		$this->School_model->insert_student($student);
		redirect('school_manage/index');
	   }
	 }
	}
	public function login_view()
	{
		$this->load->view('login');
	}
	public function check_login()
	{
		$this->form_validation->set_rules('enum','Email OR Number','required');
		$this->form_validation->set_rules('pass','Password','required');
		if($this->form_validation->run() == false)
		{
			$this->session->set_flashdata('error',validation_errors());
			$this->load->view('login');
		}
		else{
			$enum = $this->input->post('enum');
			$pass = $this->input->post('pass');
			$student['get'] = $this->School_model->login_student($enum,$pass);
			$data['result'] = $this->School_model->login_teacher($enum,$pass);
			$data['stud'] = $this->School_model->stud_data();
			if($student['get'] != null && $data['result'] == null)
			{
				$this->load->view('student_view',$student);
			}
			elseif($student['get'] == null && $data['result'] != null){
				$this->login($data);
				// $this->load->view('teacher_view',$data);
			}
			else{
				
				$this->session->set_flashdata('error','Something Went Wrong...');
				redirect('school_manage/login_view');

			}
		}
	}
	public function login($data){
    $this->load->view("teacher_view",$data);
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('school_manage/index');
		
	}
	public function editdata()
	{

	 $name = $this->input->post('uname');
	 $id = $this->input->post('id');
	 $email = $this->input->post('email');
	 $num = $this->input->post('num');
	 $opass = $this->input->post('opass');
	 $npass = $this->input->post('npass');
	 
	 if($opass== $npass)
	 {
	  $update = array(
		'teaname' => $name,
		'teaemail'=> $email,
		'teanumber' => $num,
		'teapassword' => $npass,
	  );
	//   log_message('error',json_encode($update));
	  $this->School_model->update($update,$id);

	}
	}
	public function register_view(){
		$this->load->view('register_ajax');
	}

	public function ajax_register(){
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$number = $this->input->post('number');

		if($name != '' && $email != '' && $number != ''){
		
		$data = array(
			'name' => $name,
			'email' => $email,
			'number' => $number,
		);

		$response = $this->School_model->ajax_insert($data);

		echo json_encode($response);

		} else{
          redirect('school_manage/register_view');
		}
		
	}

	public function ajax_userdata(){
		$data['user'] = $this->School_model->get_userdata();

		echo json_encode($data);
	}
		
	

}
