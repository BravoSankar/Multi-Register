<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
        <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <title> Login Page </title>
</head>
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }
    body{
        background-color: #dfe9f5;
    }
    .login{
        width:330px;
        padding: 2rem 1rem;
        margin: 50px auto;
        background-color: #fff;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 20px 35px rgba(0,0,0,0.1);
    }
    h2{
        margin-bottom: 3rem;
        font-size: 2rem;
        color: #07001f;
    }
    form input{
        width: 92%;
        background-color: #e4e4e4;
        margin-bottom: 10px;
        border-radius: 20px;
        padding: 12px 20px;
        border: 1px solid #fff;
        outline: none;
    }
    button{
        margin-top: 1.5rem;
        font-size: 1rem;
        padding: 10px 0;
        width: 90%;
        color: #fff;
        cursor: pointer;
        background-color: rgb(17,107,143);
        border-radius: 20px;
        border: none;
        outline: none;
    }
    button:hover{
         background-color: rgba(17, 107,143,0.877);
    }
    span{
        color: red;
        font-size: 0.8rem;
    }
    p{
        margin-top: 1rem;
        font-weight: 700;
    }
    a{
        color: white;
        text-decoration: none;
    }
    #eye{
        position: absolute;
        cursor: pointer;
        font-size: 1.5rem;
        left: 53.5rem;
       top: 23.5rem;
    }
</style>
<script>
    $("document").ready(function(){
        const pass = $("#pass");
        $("#eye").click(function()
        {
          if(pass.prop("type") == "password")
          {
            $(this).addClass("fa-eye");
            pass.attr("type","text");
          }
          else{
            $(this).removeClass("fa-eye");
            pass.attr("type","password");
          }
        });
    });
</script>
<body>
    <div class="login">
        <h2> Student / Teacher Login Page </h2>
        <form action="<?php echo base_url('school_manage/check_login');?>" method="post">
        <label> Email/Number :</label>
        <input type="text" name="enum" placeholder="Enter Email OR Number" value="<?php set_value('enum');?>"/>
        <span><?php echo form_error('enum');?></span>
        <label> Password :</label>
        <input type="password" name="pass" id="pass" placeholder="Enter The Password" value="<?php set_value('pass');?>"/><i id="eye" class="fa-solid fa-eye-slash"></i>
        <span><?php echo form_error('pass');?></span>
        <button type="submit" id="login"> Login</button>
        <p> Don't Have Account Please Register Here... </p>
        <button type="button"><a href="<?php echo base_url('school_manage/index');?>"> Register</a></button>
    </form>
</div>
</body>
</html>