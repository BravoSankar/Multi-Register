<!DOCTYPE html>
<title>Register Using Ajax</title>
<head>
    <meta charset="UTF-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    
</head>
<body>
    <center>
        <h2> Register  Data Using Ajax </h2>
        <form id="form">
            <label>Enter The Name :</label>
            <input type="text" name="name" placeholder="Enter The Name..."/>
            <br>
            <br>
            <label>Enter The Email :</label>
            <input type="email" name="email" placeholder="Enter The Email..."/>
            <br>
            <br>
            <label>Enter The Number :</label>
            <input type="tel" name="number" placeholder="Enter The Number"/>
            <br>
            <br>
            <button type="submit" onclick="registerData(); return false;">Submit</button>
        </form>
        <br>
        <br>
        <br>
        <div id="table">

        </div>
    </center>
</body>
<script type="text/javascript">
function registerData(){
    var data = $("#form").serialize();
    $.ajax({
        url: '<?php echo base_url('school_manage/ajax_register');?>',
        type: "post",
        data: data,
        dataType: 'json',
        success: function(data){
           $("#form")[0].reset();
           if(data == true || data == 'true'){
            alert('Registered Successfully....');
           }
           getData();
        },
        error: function(){
            alert('Error');
        }
    });
}

getData();

function getData(){
    $.ajax({
      url: '<?php echo base_url('school_manage/ajax_userdata');?>',
      type: 'post',
      dataType: 'json',
      success: function(response){
        var html ='';
        var i;
        html+='<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Number</th></tr>';
        for(i in response.user){
            html+='<tr><td>'+response.user[i].id+'</td><td>'+response.user[i].name+'</td><td>'+response.user[i].email+'</td><td>'+response.user[i].number+'</td></tr>';
        }
        html+='</table>';
        $("#table").html(html);
      }
    });
}
</script>
</html>

