<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Student Page</title>
</head>
<style>
    table{
        border : 1px solid black;
        width : 35%;
    }
    th,td{
        border: 1px solid black;
        text-align : center;
    }
    a{
        text-decoration: none;
    }
</style>
<body>
    <center>
    <h2> HI <?php echo $get->stuname;?></h2>
    <br>
    <br>
    <table>
        <tr>
            <th> Name </th>
            <th> Number </th>
            <th> Email </th>
            <th> Password</th>
            <th> Update</th>
        </tr>
        <tr>
            <td><?php echo $get->stuname;?></td>
            <td><?php echo $get->stunumber;?></td>
            <td><?php echo $get->stuemail;?></td>
            <td><?php echo $get->stupassword;?></td>
            <td><button><a href="<?php echo base_url('school_manage/edit_data');?>"> Edit</a></button></td>
        </tr>
    </table>
    <br>
    <br>
    <button><a href="<?php echo base_url('school_manage/logout');?>"> Logout</a></button>
</center>
</body>
</html>