<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <title> Teacher</title>
</head>
<style>
    table {
        border: 1px solid black;
        width: 45%;
    }

    th,
    td {
        text-align: center;
        border: 1px solid black;
    }

    a {
        text-decoration: none;
    }

    * {
        margin: 0;
        padding: 0;
        font-family: "Poppins", sans-serif;
        box-sizing: border-box;
        text-decoration: none;
    }

    body {
        background-color: #dfe9f5;
    }

    nav {
        background-color: rgb(17, 107, 143);
        width: 100%;
        height: 80px;
    }

    label.title {
        color: #fff;
        font-size: 25px;
        font-weight: bold;
        padding: 0 100px;
        line-height: 70px;
    }

    nav ul {
        float: right;
        list-style: none;
        margin-right: 40px;
    }

    nav li {
        display: inline-block;
        margin: 0 8px;
        line-height: 70px;
    }

    nav a {
        color: #fff;
        text-transform: capitalize;
        font-size: 20px;
        border: 1px solid transparent;
        border-radius: 3px;
        padding: 7px 10px;
    }

    a.active,
    a:hover {
        border: 1px solid white;
        transition: 0.3s ease;
    }

    label.bars {
        color: #fff;
        font-size: 24px;
        line-height: 70px;
        float: right;
        margin-right: 40px;
        cursor: pointer;
        display: none;
    }

    .student-data {
        display: none;
    }

    @media (max-width: 1048px) {
        label.title {
            font-size: 32px;
            padding-left: 60px;
        }

        nav ul {
            margin-left: 20px;
        }

        nav a {
            font-size: 17px;
        }
    }

    @media (max-width: 909px) {
        label.bars {
            display: block;
        }

        nav ul {
            position: fixed;
            height: 100vh;
            width: 100%;
            top: 80px;
            left: -100%;
            text-align: center;
            background: #2f3640;
            transition: all 0.5s ease;
        }

        nav li {
            display: block;
            margin: 50px 0;
            line-height: 30px;
        }

        nav a {
            font-size: 22px;
        }

        a.active,
        a:hover {
            border: none;
            color: #3498db;
        }

        nav ul.show {
            left: 0;
        }

    }

    .editform {
        width: 245px;
        background-color: #fff;
        padding: 2rem 1rem;
        margin: 40px auto;
        text-align: center;
        border-radius: 10px;
        box-shadow: 0 20px 35px rgba(0, 0, 0, 0.1);
        display: none;
    }

    .h2 {
        margin-bottom: 20px;
        font-size: 2rem;
    }

    form input {
        width: 90%;
        margin-bottom: 10px;
        padding: 12px 20px;
        background-color: #e4e4e4;
        border-radius: 20px;
        border: 1px solid #fff;
        outline: none;
    }

    form label {
        color: blue;
        font-size: 1rem;
        font-weight: 550;
    }

    form button {
        margin-top: 1.5rem;
        padding: 10px 0;
        width: 90%;
        border-radius: 20px;
        outline: none;
        cursor: pointer;
        border: none;
        background-color: rgb(17, 107, 143);
        color: #fff;
        font-size: 1rem;
    }

    form button:hover {
        background-color: rgba(17, 107, 143, 0.877);
    }

    #error {
        color: red;
        display: none;
    }
</style>
<script>
    $(document).ready(function() {
        //    nav Bar Click
        $(".bars").click(function() {
            $("ul").toggleClass("show");
        });
        $("#table").each(function() {
            var pass = $(this).find("td").eq(3).text();
        });

        $("#edit").click(function() {
            $(".editform").show();

        });
        $("#update").click(function() {
            alert($("#admin").serialize());
            $.ajax({
                url: "editdata",
                type: "post",
                data: $("#admin").serialize(),
                success: function(d) {}
            });
        });
        $("#cancel").click(function() {
            $(".editform").hide();
        });

    });

    function studentTable() {
        alert('test');
        $('.student-data').css('display', 'block');
    }
</script>

<body>
    <nav>
        <label class="title"> HI <?php echo $result->teaname; ?></label>
        <ul>
            <li><a class="active" href="#">Home</a></li>
            <li><a href="#" onclick="studentTable(); return false;">Student</a></li>
            <li><a href="#">Profile</a></li>
            <li><a href="<?php echo base_url('school_manage/logout'); ?>">Log Out</a></li>
            <li><a href="#">About</a></li>
        </ul>
        <label class="bars"><i class="fa fa-bars"></i></label>
    </nav>
    <center>
        <!-- <h2> HI <?php echo $result->teaname; ?></h2> -->
        <br>
        <br>
        <table id="table">
            <tr>
                <th> Name </th>
                <th> Email </th>
                <th> Number </th>
                <th> Password </th>
                <th> Update</th>
            </tr>
            <tr>
                <td><?php echo $result->teaname; ?></td>
                <td><?php echo $result->teaemail; ?></td>
                <td><?php echo $result->teanumber; ?></td>
                <td><?php echo $result->teapassword; ?></td>
                <td><button id="edit"> Edit</button></td>
            </tr>
        </table>
        <br>
        <br>
        <div class="student-data">
            <table>
                <tr>
                    <th> ID </th>
                    <th> Name </th>
                    <th> Email </th>
                    <th> Number </th>
                    <th> Password </th>
                </tr>
                <?php $test = '';
                foreach ($stud as $students) {
                ?>
                    <tr>
                        <td><?php $test = 'sankar' . $students['stuname'];
                            echo $students['id']; ?></td>
                        <td><?php echo $students['stuname']; ?></td>
                        <td><?php echo $students['stuemail']; ?></td>
                        <td><?php echo $students['stunumber']; ?></td>
                        <td><?php echo $students['stupassword']; ?></td>
                        <td><?php echo $test;?></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </center>
    <div class="editform">
        <h2> Edit Details </h2>
        <form id="admin" method="post">
            <input type="hidden" name="id" value="<?php echo $result->id; ?>">
            <label>Enter The Name:</label>
            <input type="text" name="uname" placeholder="Enter The Name" value="<?php echo $result->teaname; ?>" />
            <label> Email:</label>
            <input type="email" name="email" placeholder="Enter The Email" value="<?php echo $result->teaemail; ?>" />
            <label> Number:</label>
            <input type="tel" name="num" placeholder="Enter The Number" value="<?php echo $result->teanumber; ?>" />
            <label> Old Password:</label>
            <input type="text" id="opass" name="opass" placeholder="Enter The Old Password" />
            <span id="error">Incorrect Old Password...!</span>
            <label> Password:</label>
            <input type="password" name="npass" id="npass" placeholder="Enter The New Password" />
            <label> Confirm Password:</label>
            <input type="password" name="cpass" id="cpass" placeholder="Enter Confirm Password" />
            <button type="button" id="update"> Update</button>
            <button type="button" id="cancel"> Cancel</button>

        </form>
    </div>

</body>

</html>