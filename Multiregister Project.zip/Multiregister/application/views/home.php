<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <title> School Management</title>
</head>
<style>
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
   }        
body{
    background-color: #dfe9f5;
}
.wrapper{
    width: 330px;
    padding: 2rem 1rem;
    margin: 50px auto;
    background-color: #fff;
    border-radius:10px;
    text-align: center;
    box-shadow: 0 20px 35px rgba(0,0,0,0.1);
    }
    h2{
        font-size: 2rem;
        color: #07001f;
        margin-bottom: 1.2rem;
    }
    form input {
        width: 92%;
        outline: none;
        border : 1px solid #fff;
        padding: 12px 20px;
        margin-bottom: 10px;
        border-radius: 20px;
        background-color: #e4e4e4;
    }
    .register{
        display:none;
        
    }
    button{
     font-size: 1rem;
     margin-top: 1.8rem;
     padding: 10px 0;
     outline: none;
     border: none;
     border-radius: 20px;
     width: 90%;
     color: #fff;
     cursor: pointer;
     background-color: rgb(17 , 107, 143);
    }
    button:hover {
        background-color: rgba(17 , 107 , 143 , 0.877);
    }
    input:focus{
        border: 1px solid rgb(192 ,192, 192);
    }
    a {
        text-decoration : none;
        color: white;
    }
    .strength p{
        font-size: 1rem;
        font-weight: 700;
        display: none;
    }
    .error{
        color: red;
        font-size: 1rem;
        font-weight: 700;
        display :none;
    }
    #eye{
       position: absolute;
       left: 54rem;
       top: 24rem;
       font-size: 1.5rem;
       cursor: pointer;
    }
    /* .fa-eye-slash{
        position: absolute;
       left: 54rem;
       top: 24rem;
       font-size: 1.5rem;
       cursor: pointer;
    } */
</style>
<script type="text/javascript">
    // Show And Hide Radio Button
    $(document).ready(function(){
       $('input[type="radio"]').click(function(){
        var value = $(this).attr("value");
        var target = $("."+value);
        $(".register").not(target).hide();
        $(target).show();
       });
    //    Show And Hide Password
      const password = $("#cpass");
      $("#eye").click(function(){
       
          if(password.prop("type") == "password")
          {
            $(this).addClass("fa-eye");
            password.attr("type","text");
          }
          else{
            password.attr("type","password");
            $(this).removeClass("fa-eye");
          }
      });
    //    Validate Password Rules
       var upper = new RegExp('[A-Z]');
       var lower = new RegExp('[a-z]');
       var number = new RegExp('[0-9]');
       $("#pass").click(function (){
          $(".strength p").css("display","block");
       });
       $("#pass").keyup(function (){
        var pass = $("#pass").val();
        if (pass.length >= 8)
        {
          $(".eight").css("color","green");
        }
        else{
            $(".eight").css("color","red");
        }
        if(pass.match(upper))
        {
          $(".upper").css("color","green");
        }
        else{
         $(".upper").css("color","red");
        }
        if(pass.match(lower))
        {
            $(".lower").css("color","green");
        }
        else{
            $(".lower").css("color","red");
        }
        if(pass.match(number))
        {
            $(".number").css("color","green");
        }
        else{
            $(".number").css("color","red");
        }
       });
       $("#cpass").keyup(function(){
          $(".strength p").css("display","none");
          var cpass = $(this).val();
          
          if(cpass != $("#pass").val())
          {
             $(".error").css("display","block");
          }
          else if(cpass == $("#pass").val()){
            $(".error").css("display","none");
          }
       });
       $("#enter").click(function() {
        var pass = $("#pass").val();
        var cpass = $("#cpass").val(); 
        if(cpass != pass)
        {
          return false;
        }
        else{
            return true;
        }
});
    });
</script>
<body>
    <div class="wrapper">
        <h2> Register Page </h2>
        <form action="<?php echo base_url('school_manage/insert');?>" method="post">
            <input type="text" placeholder="Enter The First Name" name="name"/>
            <p><?php echo form_error('name');?></p>
            <input type="tel" placeholder="Enter The Number" name="num"/>
            <input type="email" placeholder="Enter The Email" name="email" />
            <input type="password" name="pass" id="pass" placeholder="Enter The Password"/>
            <div class="strength">
            <p class="upper">Upper Case &nbsp;&nbsp;<i class="fa-solid fa-check"></i></p>
            <p class="lower">Lower Case &nbsp;&nbsp;<i class="fa-solid fa-check"></i></p>
            <p class="number">Numbers &nbsp; &nbsp; <i class="fa-solid fa-check"></i></p>
            <p class="eight">8 Characters &nbsp; &nbsp;<i class="fa-solid fa-check"></i></p>
            </div>
            <input type="password" id="cpass" placeholder="Confirm Password"/><i id="eye" class="fa-solid fa-eye-slash"></i>
            <span class="error">Password Did Not Match...</span>
            <input type="radio" id="teach"  name="find" value="one">Teacher</input>
            <input type="radio" id="stud" name="find" value="two">Student</input>
            <div id="teacher" class="register one">
                   Hi Teacher
            </div>
            <div id="student" class="register two">
                Hi Student
            </div>
            <button type="submit" onclick="insertData(); return false;" id="enter"> Register</button>
        </form>
        <button type="button"><a href="<?php echo base_url('school_manage/login_view');?>" > Login</a></button>
</div>
</body>
</html>